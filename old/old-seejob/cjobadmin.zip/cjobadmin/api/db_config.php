<?php
	@define (DB_USER, "root");
	@define (DB_PASSWORD, "");
	@define (DB_DATABASE, "cjobcjob");
	@define (DB_HOST, "localhost");
	$mysqli = new mysqli(DB_HOST, DB_USER, DB_PASSWORD, DB_DATABASE);
	// $mysqli = mysqli_connect("166.62.27.148","xtvpm2l","GodhelpME@123","cjobcjob");

	
	
?>