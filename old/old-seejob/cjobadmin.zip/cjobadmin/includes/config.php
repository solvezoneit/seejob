<?php
// error_reporting(0);

// $db = mysqli_connect("localhost","root","root","click_us_india");
$db = mysqli_connect("localhost","root","","cjobcjob");
// $db = mysqli_connect("localhost","xtvpm2l","GodhelpME@123","cjobcjob");
// $db = mysqli_connect("166.62.27.148","xtvpm2l","GodhelpME@123","cjobcjob");

?>

