<?php
$title="Home";
include("include/head.php"); 
?>
<div class="page-container" >	
   <div class="left-content">
	   <div class="mother-grid-inner">
         <?php include("include/header.php"); ?>   

<!-- main Content Start --->

<!--inner block start here-->
<div class="inner-block">
    <div class="blank">
    	<!--  Blog Start -->
		<div class="col-md-4 market-update-gd">
				<div class="market-update-block clr-block-1">
					<div class="col-md-8 market-update-left">
						
<?php
$sr="1";
$sql = "SELECT * from  admin_reg ORDER BY admin_reg_id DESC";
$result = $conn->query($sql);

if ($result->num_rows > 0) {
    // output data of each row
    while($row = $result->fetch_assoc()) 
	{
?>
						<h3><?php echo $sr; //echo  $row['admin_reg_id']; ?></h3>
						<h4>Registered User</h4>
						<p>Administrator</p>
<?php
$sr++;
    }
}
 else 
	{
		echo "<h3>0</h3>";	
	}

//$conn->close();
?>
					</div>
					<div class="col-md-4 market-update-right">
						 <label class="dashboard_lable_icon glyphicon glyphicon-user"> </label>
					</div>
				  <div class="clearfix"> </div>
				</div>
			</div>
		<!-- Blog End-->
		<!--  Blog Start -->
		<div class="col-md-4 market-update-gd">
				<div class="market-update-block clr-block-1">
					<div class="col-md-8 market-update-left">
						
<?php
$sr="1";
$sql = "SELECT * from  states ORDER BY s_id DESC";
$result = $conn->query($sql);

if ($result->num_rows > 0) {
    // output data of each row
    while($row = $result->fetch_assoc()) 
	{
	$sr++;
    }
?>
						<h3><?php echo $sr; //echo  $row['admin_reg_id']; ?></h3>
						<h4>Total State</h4>
						<p>&nbsp;</p>
<?php

}
 else 
	{
		echo "<h3>0</h3>";	
	}

//$conn->close();
?>
					</div>
					<div class="col-md-4 market-update-right">
						 <label class="dashboard_lable_icon glyphicon glyphicon-map-marker"> </label>
					</div>
				  <div class="clearfix"> </div>
				</div>
			</div>
		<!-- Blog End-->
		<!--  Blog Start -->
		<div class="col-md-4 market-update-gd">
				<div class="market-update-block clr-block-1">
					<div class="col-md-8 market-update-left">
						
<?php
$sr="1";
$sql = "SELECT * from  cities ORDER BY c_id DESC";
$result = $conn->query($sql);

if ($result->num_rows > 0) {
    // output data of each row
    while($row = $result->fetch_assoc()) 
	{
$sr++;
    }
?>
						<h3><?php echo $sr; //echo  $row['admin_reg_id']; ?></h3>
						<h4>Total District | City</h4>
						<p>&nbsp;</p>
<?php
}
 else 
	{
		echo "<h3>0</h3>";	
	}

//$conn->close();
?>
					</div>
					<div class="col-md-4 market-update-right">
						 <label class="dashboard_lable_icon glyphicon glyphicon-map-marker"> </label>
						 <p></p>
					</div>
				  <div class="clearfix"> </div>
				</div>
			</div>
		<!-- Blog End--><br /><br /><br /><br /><br /><br /><br /><br /><br />
		
		
		
			
			
			
			


		
    </div>
</div>
<!--inner block end here-->



<!-- ----main Content End  --->
<?php include("include/footer.php"); ?>
</div>
</div>
<?php include("include/sidemenu.php"); ?>

<!--scrolling js-->
		<script src="js/jquery.nicescroll.js"></script>
		<script src="js/scripts.js"></script>
		<!--//scrolling js-->
<script src="js/bootstrap.js"> </script>
<!-- mother grid end here-->
</body>
</html>                     