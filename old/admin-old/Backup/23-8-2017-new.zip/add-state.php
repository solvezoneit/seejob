<?php
$title="Home";
$bntCap="Submit";
include("include/head.php");
$state_id="";
$state_name="";
$state_sort_name="";
$state_country_id="";
if(array_key_exists("edit",$_REQUEST))
	{
		$bntCap="Update";
		$sql = "SELECT * from  state where state_id='$_REQUEST[edit]'";
		$result = $conn->query($sql);
		$row = $result->fetch_assoc();
		$state_id=$row['state_id'];
		$state_name=$row['state_name'];
		$state_sort_name=$row['state_sort_name'];
		$state_country_id=$row['state_country_id'];
	} 
?>
<link href="http://maxcdn.bootstrapcdn.com/bootstrap/3.2.0/css/bootstrap.min.css" rel="stylesheet">
<script src="http://ajax.googleapis.com/ajax/libs/jquery/1.7.1/jquery.min.js"></script>
<link rel="stylesheet" href="http://cdn.datatables.net/1.10.2/css/jquery.dataTables.min.css"></style>
<script type="text/javascript" src="http://cdn.datatables.net/1.10.2/js/jquery.dataTables.min.js"></script>
<script type="text/javascript" src="http://maxcdn.bootstrapcdn.com/bootstrap/3.2.0/js/bootstrap.min.js"></script>
<div class="page-container" >	
   <div class="left-content">
	   <div class="mother-grid-inner">
         <?php include("include/header.php"); ?>   

<!-- main Content Start --->

<!--inner block start here-->
<div class="inner-block">
    <div class="blank">
    	<?php
				if(array_key_exists("msg",$_REQUEST))
				{
				?>
					<div class="alert alert-danger" role="alert">
						<button type="button" class="close" data-dismiss="alert" aria-label="Close">  <span aria-hidden="true">&times;</span></button>
						<p class="text-center"><?php echo $_REQUEST['msg']; ?></p>
					</div>
				<?php
				} 
		?>
		
    
	<br />	
	    <form action="include/query.php" method="post" enctype="multipart/form-data">
		<table class="table table-bordered">
			<tr>
				<th> Country Name</th>
				<td>
					<select class="form-control" name="state_country_id">
								<option value="" >Plese Select Country Name </option>
		  <?php
$sr="1";
$state_detail_id="";
$sel="";
$sql = "SELECT * from  country ORDER BY country_id DESC";
$result = $conn->query($sql);
if ($result->num_rows > 0) 
{
    // output data of each row
    while($row = $result->fetch_assoc()) 
		{
$s_id1=$row['country_id'];
if($s_id1 == $state_country_id)
	{
		$sel="selected";
	}
else
	{
		$sel="";
	}		
?>	
		<option <?php echo $sel; ?>  value="<?php echo  $s_id1; ?>"><?php echo  $row['country_name']; ?></option>
<?php
$sr++;
   	 }
}
?>
							 </select>
				</td>
				<th class="text-center">
					State Name
				</th>
				<th > 
					<div class="row">
						<div class="col-md-8">
							<input type="text" name="state_name" placeholder="State Name" required="" class="form-control" value="<?php echo $state_name; ?>">
						</div>
						<div class="col-md-4">
							<input type="text" name="state_sort_name" placeholder="State Sort Name" required="" class="form-control" value="<?php echo $state_sort_name; ?>">
						</div>
					</div>
				</th >
				
				<th>
					<input class="btn btn-success" type="submit" name="add_satae" value="<?php echo $bntCap; ?>">
					<input type="hidden" value="<?php echo $state_id ?>" name="state_id">	
				</th>
			</tr>
			</table>
			</form>
			<table id="myTable1" class="table table-striped resposive" >  
			 <thead>  
          <tr>
		  		<td>Sr. No.</td>
				<td>Country Name</td>
				<td>State Name</td>
				<td>State Sort Name</td>
				<td>Action</td>
		  </tr>
		  </thead>
		  <?php
$sr="1";
$sql = "SELECT * from  state,country where state_country_id=country_id  ORDER BY state_id DESC";
$result = $conn->query($sql);

if ($result->num_rows > 0) 
{
    // output data of each row
    while($row = $result->fetch_assoc()) 
	{
?>
		 <tr>
		  		<td><?php echo $sr; ?></td>
				<td><?php echo  $row['country_name']; ?></td>
				<td><?php echo  $row['state_name']; ?></td>
				<td><?php echo  $row['state_sort_name']; ?></td>
				<td class="text-center">
				<a href="add-state.php?edit=<?php echo  $row['state_id']; ?>"><label class="glyphicon glyphicon-edit"></label></a>
				<a href="#" onClick="delRecord('<?php echo  $row['state_id']; ?>')"> <label class="glyphicon glyphicon-trash"></label></a>
				</td>
		  </tr>
<?php
$sr++;
    }
}
$conn->close();

?>
		</table>
    </div>
</div>
<!--inner block end here-->

</form>
<form name="admin" action="include/query.php" method="get">       	
<input type="hidden" name="delete_state">
</form>
<script>
function delRecord(id)
{
	if(confirm("Are you Soure you want to delete"))
	{
		document.admin.delete_state.value=id;
		document.admin.submit();
	}
}
</script>	

<!-- ----main Content End  --->
<?php include("include/footer.php"); ?>
</div>
</div>
<?php include("include/sidemenu.php"); ?>

<!--scrolling js-->
		<script src="js/jquery.nicescroll.js"></script>
		<script src="js/scripts.js"></script>
		<!--//scrolling js-->
<script src="js/bootstrap.js"> </script>
<!-- mother grid end here-->
</body>
<script>
$(document).ready(function(){
    $('#myTable1').dataTable();
});
</script>
</html>                     