<?php
$title="Home";
$bntCap="Submit";
include("include/head.php");
$state_detail_id="";
$state_detail_name="";
?>
<!--   #################    #######################-->
<!-- ///////////////// State Select  Start  ////////////// -->
<script src="https://code.jquery.com/jquery-1.12.4.min.js"></script>
<script type="text/javascript">
$(document).ready(function(){
    $("select.country").change(function(){
        var selectedCountry = $(".country option:selected").val();
        $.ajax({
            type: "POST",
            url: "process-request.php",
            data: { country : selectedCountry } 
        }).done(function(data){
            $("#response").html(data);
        });
    });
});
</script>
<!-- ///////////////// State Select  End  ////////////// -->
<!-- ///////////////// Input box search  Start  ////////////// -->
<!--   #################    #######################-->
<div class="page-container" >	
   <div class="left-content">
	   <div class="mother-grid-inner">
         <?php include("include/header.php"); ?>   

<!-- main Content Start --->

<!--inner block start here-->
<div class="inner-block">
    <div class="blank">
    	<!---Start -->
	<form action="" method="post" enctype="multipart/form-data">
	<table class="table table-bordered">
			<tr>
				<td width="50%"> 
				<div class='row'><div class='col-md-6 text-center'>State Name </div>
				<div class='col-md-6'>
                <select class="country form-control">
                    <option>Select</option>
                    <?php
$sr="1";
$state_detail_id="";
$sel="";
$sql = "SELECT * from  states ORDER BY s_name ASC";
$result = $conn->query($sql);
if ($result->num_rows > 0) 
{
    // output data of each row
    while($row = $result->fetch_assoc()) 
		{
$state_detail_id=$row['s_id'];
if($state_detail_id==$district_state_id)
	{
		$sel="selected";
	}
else
	{
		$sel="";
	}		
?>	
		<option <?php echo $sel; ?>  value="<?php echo  $state_detail_id; ?>"><?php echo  $row['s_name']; ?></option>
<?php
$sr++;
   	 }
}
?>
                </select> </div>
            </td>
            <td id="response">
                <!--Response will be inserted here-->
            </td>
				
			</tr>
		</table>
		</form>	  


<!--- end -->
    
	<br />	
		
    </div>
</div>
<!--inner block end here-->
	

<!-- ----main Content End  --->
<?php include("include/footer.php"); ?>
</div>
</div>
<?php include("include/sidemenu.php"); ?>

<!--scrolling js-->
		<script src="js/jquery.nicescroll.js"></script>
		<script src="js/scripts.js"></script>
		<!--//scrolling js-->
<script src="js/bootstrap.js"> </script>
<!-- mother grid end here-->
</body>
</html>                     