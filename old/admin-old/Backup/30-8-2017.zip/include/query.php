<?php  
include("conection.php");
#####################################  Login  Page  Start ######################################
if(array_key_exists("Admin_login",$_REQUEST))
	{
				
$sql="SELECT * from  admin_reg where admin_reg_email='$_REQUEST[admin_reg_email]' and admin_reg_password='$_REQUEST[admin_reg_password]'";
$result = $conn->query($sql);
	if ($result->num_rows > 0)
		{
		// output data of each row
			$row = $result->fetch_assoc();
			if($row['admin_reg_password']==$_REQUEST['admin_reg_password'])
			{
				$_SESSION['user']=$row[admin_reg_name];
				
				header("location:../index.php");	
			}
			else
			{
				$msg="Invalid Password! try again";
				header("Location:../login.php?msg=$msg ");
			}
		}
	else
		{
			$msg="Invalid Password! try again";
			header("Location:../login.php?msg=$msg ");
		}
	}
#####################################  ----- End   --------------   ##############################################
################################   ---     Admin  Insert Update & Delete  Start  ---     ############################
				//////// Registration (Insert & Update ) /////////
if(array_key_exists("admin_reg",$_REQUEST))
	{
	 if($_REQUEST['admin_reg']=="Submit")
		{
			$pass=md5($_REQUEST['admin_reg_password']);
			$sql="insert into admin_reg set
			admin_reg_name='$_REQUEST[admin_reg_name]',
			admin_reg_email='$_REQUEST[admin_reg_email]',
			admin_reg_password='$_REQUEST[admin_reg_password]'";
			if ($conn->query($sql) === TRUE) 
				{
					$msg= "Record Save successfully";
					header("Location:../rergistration.php?msg=$msg ");
				} 
			else 
				{
					echo "Error: " . $sql . "<br>" . $conn->error;
				}		
		}
	if($_REQUEST['admin_reg']=="Update")
		{
			$dt=time();
			$pass=md5($_REQUEST['admin_reg_password']);
			$sql="Update admin_reg set
			admin_reg_name='$_REQUEST[admin_reg_name]',
			admin_reg_email='$_REQUEST[admin_reg_email]',
			admin_reg_password='$_REQUEST[admin_reg_password]' where admin_reg_id='$_REQUEST[admin_reg_id]'";
			if ($conn->query($sql) === TRUE) 
				{
					$msg= "Record Updated successfully";
					header("Location:../rergistration.php?msg=$msg ");
				} 
			else 
				{
					echo "Error: " . $sql . "<br>" . $conn->error;
				}		
		}
	}
		//////////////////////// Delete ////////////////////////////////////////
if(array_key_exists('delete',$_REQUEST))
{
	echo $sql="delete from admin_reg where admin_reg_id=$_REQUEST[delete]";
	if ($conn->query($sql) === TRUE) 
				{
					$msg= "Record Deleted Successfully";
					header("Location:../view_rergistration.php?msg=$msg ");
				} 
			else 
				{
					echo "Error: " . $sql . "<br>" . $conn->error;
				}
}
################################   ---     Admin  Insert Update & Delete  End  ---     ############################
							//////////////////////////////////////////////////////
#################-------------------------         Add country  Insert  Update & Delete                 -------------------#####################################
if(array_key_exists("add_country",$_REQUEST))
	{
	 if($_REQUEST['add_country']=="Submit")
		{
			$sql="insert into country set
			country_name='$_REQUEST[country_name]',
			country_sort_name='$_REQUEST[country_sort_name]',
			country_pin_code='$_REQUEST[country_pin_code]'";
			if ($conn->query($sql) === TRUE) 
				{
					$location="country";
					$sql1 = "SELECT * from  country ORDER BY country_id DESC";
					$result1 = $conn->query($sql1);
					$row1 = $result1->fetch_assoc();
					$country_id=$row1['country_id'];
					$country_name=$row1['country_name'];
							###############
					$sql2="insert into location set
					location_name='$country_name',
					location_id_country_state_district_city='$country_id',
					location_table_country_state_district_city='$location'";
					$conn->query($sql2);
							#########
					$msg= "Record Save successfully";
					header("Location:../add-country.php?msg=$msg ");
				} 
			else 
				{
					echo "Error: " . $sql . "<br>" . $conn->error;
				}		
		}
	if($_REQUEST['add_country']=="Update")
		{
			$u_contry_id=$_REQUEST['country_id'];
			$sql="Update country set
			country_name='$_REQUEST[country_name]',
			country_sort_name='$_REQUEST[country_sort_name]',
			country_pin_code='$_REQUEST[country_pin_code]' where country_id='$_REQUEST[country_id]'";
			if ($conn->query($sql) === TRUE) 
				{
					$location="country";
					$sql1 = "SELECT * from  country Where country_id='$u_contry_id'";
					$result1 = $conn->query($sql1);
					$row1 = $result1->fetch_assoc();
					$country_id=$row1['country_id'];
					$country_name=$row1['country_name'];
							###############
					$sql2="Update location set
					location_name='$_REQUEST[country_name]' where location_id_country_state_district_city='$u_contry_id' and location_table_country_state_district_city='$location'";
					$conn->query($sql2);
							#########
					$msg= "Record Updated successfully";
					header("Location:../add-country.php?msg=$msg ");
				} 
			else 
				{
					echo "Error: " . $sql . "<br>" . $conn->error;
				}		
		}
	}  
if(array_key_exists('delete_country',$_REQUEST))
{
	 $u_contry_id=$_REQUEST['delete_country'];
	 $sql="delete from country where country_id=$_REQUEST[delete_country]";
	if ($conn->query($sql) === TRUE) 
				{
					$sql3="delete from location where location_id_country_state_district_city=$_REQUEST[delete_country]";
					$conn->query($sql3);					
					$msg= "Record Deleted Successfully";
					header("Location:../add-country.php?msg=$msg ");
				} 
			else 
				{
					echo "Error: " . $sql . "<br>" . $conn->error;
				}
} 
########################## ---------  End ---- #########################################
#######    ----------   State  ( Update , Delete & Insert  ----------------     #########
if(array_key_exists("add_satae",$_REQUEST))
	{
	 if($_REQUEST['add_satae']=="Submit")
		{
			$sql="insert into state set
			state_name='$_REQUEST[state_name]',
			state_sort_name='$_REQUEST[state_sort_name]',
			state_country_id='$_REQUEST[state_country_id]'";
			if ($conn->query($sql) === TRUE) 
				{
					$location="state";
					$sql1 = "SELECT * from  state ORDER BY state_id DESC";
					$result1 = $conn->query($sql1);
					$row1 = $result1->fetch_assoc();
					$country_id=$row1['state_id'];
					$country_name=$row1['state_name'];
							###############
					$sql2="insert into location set
					location_name='$country_name',
					location_id_country_state_district_city='$country_id',
					location_table_country_state_district_city='$location'";
					if($conn->query($sql2) == true)
						{
							$msg= "Record Save successfully";
							header("Location:../add-state.php?msg=$msg ");
						}
					else
						{
							echo "Error: " . $sql . "<br>" . $conn->error;
						}
				} 
			else 
				{
					echo "Error: " . $sql . "<br>" . $conn->error;
				}		
		}
	if($_REQUEST['add_satae']=="Update")
		{
			$u_state_id=$_REQUEST['state_id'];
			echo $sql="Update state set
			state_name='$_REQUEST[state_name]',
			state_sort_name='$_REQUEST[state_sort_name]',
			state_country_id='$_REQUEST[state_country_id]' where state_id='$u_state_id'";
			if ($conn->query($sql) === TRUE) 
				{
					$location="state";
					$sql1 = "SELECT * from  state where state_id='$u_state_id'";
					$result1 = $conn->query($sql1);
					$row1 = $result1->fetch_assoc();
					$country_id=$row1['state_id'];
					$country_name=$row1['state_name'];
							###############
					$sql2="Update location set
					location_name='$country_name',
					location_table_country_state_district_city='$location' where location_id_country_state_district_city='$country_id' and location_table_country_state_district_city='$location'";
					if($conn->query($sql2) == true)
						{
							$msg= "Record Updated successfully";
							header("Location:../add-state.php?msg=$msg ");
						}
					else
						{
							echo "Error: " . $sql . "<br>" . $conn->error;
						}
				} 
			else 
				{
					echo "Error: " . $sql . "<br>" . $conn->error;
				}		
		}
	}  
if(array_key_exists('delete_state',$_REQUEST))
	{
		$state_id=$_REQUEST['delete_state'];
		$sql="delete from state where state_id=$_REQUEST[delete_state]";
		if ($conn->query($sql) === TRUE) 
					{
						$sql3="delete from location where location_id_country_state_district_city='$state_id'";
						$conn->query($sql3);
						$msg= "Record Deleted Successfully";
						header("Location:../add-state.php?msg=$msg ");
					} 
				else 
					{
						echo "Error: " . $sql . "<br>" . $conn->error;
					}
	} 

########################## ---------  District Detail Add  Start ---- #########################################
if(array_key_exists("add_district",$_REQUEST))
	{
	 if($_REQUEST['add_district']=="Submit")
		{
			$sql="insert into district set
			district_name='$_REQUEST[district_name]',
			district_country_id='$_REQUEST[district_country_id]',
			district_state_id='$_REQUEST[district_state_id]'";
			if ($conn->query($sql) === TRUE) 
				{
					$location="district";
					$sql1 = "SELECT * from  district ORDER BY district_id DESC";
					$result1 = $conn->query($sql1);
					$row1 = $result1->fetch_assoc();
					$country_id=$row1['district_id'];
					$country_name=$row1['district_name'];
							###############
					$sql2="insert into location set
					location_name='$country_name',
					location_id_country_state_district_city='$country_id',
					location_table_country_state_district_city='$location'";
					if($conn->query($sql2) == true)
						{
							$msg= "Record Save successfully";
							header("Location:../add-district.php?msg=$msg ");
						}
					else
						{
							echo "Error: " . $sql . "<br>" . $conn->error;
						}
				} 
			else 
				{
					echo "Error: " . $sql . "<br>" . $conn->error;
				}		
		}
	if($_REQUEST['add_district']=="Update")
		{
			$u_district_id=$_REQUEST['district_id'];
			$sql="Update district set
			district_name='$_REQUEST[district_name]',
			district_country_id='$_REQUEST[district_country_id]',
			district_state_id='$_REQUEST[district_state_id]' where district_id='$_REQUEST[district_id]'";
			if ($conn->query($sql) === TRUE) 
				{
					$location="district";
					$sql1 = "SELECT * from  district where district_id='$u_district_id'";
					$result1 = $conn->query($sql1);
					$row1 = $result1->fetch_assoc();
					$country_id=$row1['district_id'];
					$country_name=$row1['district_name'];
							###############
					$sql2="Update location set
					location_name='$country_name',
					location_table_country_state_district_city='$location' where location_id_country_state_district_city='$country_id' and location_table_country_state_district_city='district'";
					if($conn->query($sql2) == true)
						{
							$msg= "Record Updated successfully";
							header("Location:../add-district.php?msg=$msg ");
						}
					else
						{
							echo "Error: " . $sql . "<br>" . $conn->error;
						}
				} 
			else 
				{
					echo "Error: " . $sql . "<br>" . $conn->error;
				}		
		}
	}  
if(array_key_exists('delete_district',$_REQUEST))
{
	 $sql="delete from district where district_id=$_REQUEST[delete_district]";
	if ($conn->query($sql) === TRUE) 
				{
					$sql3="delete from location where location_id_country_state_district_city='$_REQUEST[delete_district]' and location_table_country_state_district_city='district'";
					$conn->query($sql3);
					$msg= "Record Deleted Successfully";
					header("Location:../add-district.php?msg=$msg ");
				} 
			else 
				{
					echo "Error: " . $sql . "<br>" . $conn->error;
				}
} 
########################## ---------  End ---- #########################################
                   ##############  City  Insert Update Delete ################
if(array_key_exists("add_city",$_REQUEST))
	{
		$sql = "SELECT * from  state where state_id='$_REQUEST[city_state_id]'";
		$result = $conn->query($sql);
		$row = $result->fetch_assoc();
		$city_country_id=$row['state_country_id'];
	 if($_REQUEST['add_city']=="Submit")
		{
			$sql="insert into city set
			city_name='$_REQUEST[city_name]',
			city_country_id='$city_country_id',
			city_state_id='$_REQUEST[city_state_id]',
			city_district_id='$_REQUEST[city_district_id]'"; 
			if ($conn->query($sql) === TRUE) 
				{
					$location="city";
					$sql1 = "SELECT * from  city ORDER BY city_id DESC";
					$result1 = $conn->query($sql1);
					$row1 = $result1->fetch_assoc();
					$country_id=$row1['city_id'];
					$country_name=$row1['city_name'];
							###############
					$sql2="insert into location set
					location_name='$country_name',
					location_id_country_state_district_city='$country_id',
					location_table_country_state_district_city='$location'";
					if($conn->query($sql2) == true)
						{
							$msg= "Record Save successfully";
							header("Location:../add-city.php?msg=$msg ");
						}
					else
						{
							echo "Error: " . $sql . "<br>" . $conn->error;
						}
				} 
			else 
				{
					echo "Error: " . $sql . "<br>" . $conn->error;
				}		
		}
	if($_REQUEST['add_city']=="Update")
		{
			$sql="Update city set
			city_name='$_REQUEST[city_name]',
			city_country_id='$city_country_id',
			city_state_id='$_REQUEST[city_state_id]',
			city_district_id='$_REQUEST[city_district_id]' where city_id='$_REQUEST[city_id]'";
			if ($conn->query($sql) === TRUE) 
				{
					$location="city";
					$sql1 = "SELECT * from  city where city_id='$_REQUEST[city_id]'";
					$result1 = $conn->query($sql1);
					$row1 = $result1->fetch_assoc();
					$country_id=$row1['city_id'];
					$country_name=$row1['city_name'];
							###############
					$sql2="Update location set
					location_name='$_REQUEST[city_name]' where location_id_country_state_district_city='$country_id' and location_table_country_state_district_city='city'";
					if($conn->query($sql2) == true)
						{
							$msg= "Record Updated successfully";
							header("Location:../add-city.php?msg=$msg ");
						}
					else
						{
							echo "Error: " . $sql . "<br>" . $conn->error;
						}
				} 
			else 
				{
					echo "Error: " . $sql . "<br>" . $conn->error;
				}	
					
		}
	}
if(array_key_exists('delete_city',$_REQUEST))
	{
		echo $sql="delete from city where city_id=$_REQUEST[delete_city]";
		if ($conn->query($sql) === TRUE) 
			{
				$sql3="delete from location where location_id_country_state_district_city='$_REQUEST[delete_city]' and location_table_country_state_district_city='city'";
					$conn->query($sql3);
				$msg= "Record Deleted Successfully";
				header("Location:../add-city.php?msg=$msg ");
			} 
		else 
			{
				echo "Error: " . $sql . "<br>" . $conn->error;
			}
	}
################### Sub City   Insert Delete  Update Start  ###################
              ######  -  Delete --  ########
if(array_key_exists('delete_subcity',$_REQUEST))
	{
		echo $sql="delete from subcity where subcity_id=$_REQUEST[delete_subcity]";
		if ($conn->query($sql) === TRUE) 
			{
				$sql3="delete from location where location_id_country_state_district_city='$_REQUEST[delete_subcity]' and location_table_country_state_district_city='subcity'";
				$conn->query($sql3);
				$msg= "Record Deleted Successfully";
				header("Location:../add-sub-city.php?msg=$msg ");
			} 
		else 
			{
				echo "Error: " . $sql . "<br>" . $conn->error;
			}
	}
if(array_key_exists("add_Subcity",$_REQUEST))
	{
	 if($_REQUEST['add_Subcity']=="Submit")
		{
			$sql="insert into subcity set
			subcity_name='$_REQUEST[subcity_name]',
			subcity_country_id='$_REQUEST[subcity_country_id]',
			subcity_state_id='$_REQUEST[subcity_state_id]',
			subcity_district_id='$_REQUEST[subcity_district_id]',
			subcity_city_id='$_REQUEST[subcity_city_id]'"; 
			if ($conn->query($sql) === TRUE) 
				{
					$location="subcity";
					$sql1 = "SELECT * from  subcity ORDER BY subcity_id DESC";
					$result1 = $conn->query($sql1);
					$row1 = $result1->fetch_assoc();
					$country_id=$row1['subcity_id'];
					$country_name=$row1['subcity_name'];
							###############
					$sql2="insert into location set
					location_name='$country_name',
					location_id_country_state_district_city='$country_id',
					location_table_country_state_district_city='$location'";
					if($conn->query($sql2) == true)
						{
							$msg= "Record Save successfully";
							header("Location:../add-sub-city.php?msg=$msg ");
						}
					else
						{
							echo "Error: " . $sql . "<br>" . $conn->error;
						}
				} 
			else 
				{
					echo "Error: " . $sql . "<br>" . $conn->error;
				}		
		}
	if($_REQUEST['add_Subcity']=="Update")
		{
			$dt=time();
			$sql="Update subcity set
			subcity_name='$_REQUEST[subcity_name]' where subcity_id='$_REQUEST[subcity_id]'";
			if ($conn->query($sql) === TRUE) 
				{
					$location="subcity";
					$sql1 = "SELECT * from  subcity where subcity_id='$_REQUEST[subcity_id]'";
					$result1 = $conn->query($sql1);
					$row1 = $result1->fetch_assoc();
					$country_id=$row1['subcity_id'];
					$country_name=$row1['subcity_name'];
							###############
					$sql2="Update location set
					location_name='$_REQUEST[subcity_name]' where location_id_country_state_district_city='$country_id' and location_table_country_state_district_city='subcity'";
					if($conn->query($sql2) == true)
						{
							$msg= "Record Updated successfully";
							header("Location:../add-sub-city.php?msg=$msg ");
						}
					else
						{
							echo "Error: " . $sql . "<br>" . $conn->error;
						}
				} 
			else 
				{
					echo "Error: " . $sql . "<br>" . $conn->error;
				}	
					
		}
	}
###################    Insert Delete  Update End  ###################
######################  Qualification ###################
if(array_key_exists("add_highest_qualification",$_REQUEST))
	{
	 if($_REQUEST['add_highest_qualification']=="Submit")
		{
			$sql="insert into highest_qualification set
			highest_qualification_name='$_REQUEST[highest_qualification_name]'";
			if ($conn->query($sql) === TRUE) 
				{
					$msg= "Record Save successfully";
					header("Location:../highest-qualification.php?msg=$msg ");
				} 
			else 
				{
					echo "Error: " . $sql . "<br>" . $conn->error;
				}		
		}
	if($_REQUEST['add_highest_qualification']=="Update")
		{
			$sql="Update highest_qualification set
			highest_qualification_name='$_REQUEST[highest_qualification_name]' where highest_qualification_id='$_REQUEST[highest_qualification_id]'";
			if ($conn->query($sql) === TRUE) 
				{
					$msg= "Record Updated successfully";
					header("Location:../highest-qualification.php?msg=$msg ");
				} 
			else 
				{
					echo "Error: " . $sql . "<br>" . $conn->error;
				}		
		}
	}
		//////////////////////// Delete ////////////////////////////////////////
if(array_key_exists('delete_highest_qualification',$_REQUEST))
{
	$sql="delete from highest_qualification where highest_qualification_id='$_REQUEST[delete_highest_qualification]'";
	echo $sql;
	if ($conn->query($sql) === TRUE) 
				{
					$msg= "Record Deleted Successfully";
					header("Location:../highest-qualification.php?msg=$msg ");
				} 
			else 
				{
					echo "Error: " . $sql . "<br>" . $conn->error;
				}
}
######################  Qualification Course ###################
if(array_key_exists("add_highest_qualification_course",$_REQUEST))
	{
	 if($_REQUEST['add_highest_qualification_course']=="Submit")
		{
			$sql="insert into highest_qualification_course set
			highest_qualification_course_name='$_REQUEST[highest_qualification_course_name]',
			highest_qualification_course_h_q_id='$_REQUEST[highest_qualification_course_h_q_id]'";
			if ($conn->query($sql) === TRUE) 
				{
					$msg= "Record Save successfully";
					header("Location:../qualification-course.php?msg=$msg ");
				} 
			else 
				{
					echo "Error: " . $sql . "<br>" . $conn->error;
				}		
		}
	if($_REQUEST['add_highest_qualification_course']=="Update")
		{
			$sql="Update highest_qualification_course set
			highest_qualification_course_name='$_REQUEST[highest_qualification_course_name]',
			highest_qualification_course_h_q_id='$_REQUEST[highest_qualification_course_h_q_id]' where highest_qualification_course_id='$_REQUEST[highest_qualification_course_id]'";
			if ($conn->query($sql) === TRUE) 
				{
					$msg= "Record Updated successfully";
					header("Location:../qualification-course.php?msg=$msg ");
				} 
			else 
				{
					echo "Error: " . $sql . "<br>" . $conn->error;
				}		
		}
	}
		//////////////////////// Delete ////////////////////////////////////////
if(array_key_exists('delete_highest_qualification_course',$_REQUEST))
{
	$sql="delete from highest_qualification_course where highest_qualification_course_id='$_REQUEST[delete_highest_qualification_course]'";
	echo $sql;
	if ($conn->query($sql) === TRUE) 
				{
					$msg= "Record Deleted Successfully";
					header("Location:../qualification-course.php?msg=$msg ");
				} 
			else 
				{
					echo "Error: " . $sql . "<br>" . $conn->error;
				}
}
######################  Qualification Specialization ###################
if(array_key_exists("add_course_specialization",$_REQUEST))
	{
	 if($_REQUEST['add_course_specialization']=="Submit")
		{
			$sql="insert into qualification_specialization set
			qs_hq_id='$_REQUEST[qs_hq_id]',
			qs_hqc_id='$_REQUEST[qs_hqc_id]',
			hq_name='$_REQUEST[hq_name]'";
			if ($conn->query($sql) === TRUE) 
				{
					$msg= "Record Save successfully";
					header("Location:../qualification-course-pecialization.php?msg=$msg ");
				} 
			else 
				{
					echo "Error: " . $sql . "<br>" . $conn->error;
				}		
		}
	if($_REQUEST['add_course_specialization']=="Update")
		{
			$sql="Update qualification_specialization set
			qs_hq_id='$_REQUEST[qs_hq_id]',
			qs_hqc_id='$_REQUEST[qs_hqc_id]',
			hq_name='$_REQUEST[hq_name]' where qs_id='$_REQUEST[qs_id]'";
			if ($conn->query($sql) === TRUE) 
				{
					$msg= "Record Updated successfully";
					header("Location:../qualification-course-pecialization.php?msg=$msg ");
				} 
			else 
				{
					echo "Error: " . $sql . "<br>" . $conn->error;
				}		
		}
	}
		//////////////////////// Delete ////////////////////////////////////////
if(array_key_exists('delete_specialization',$_REQUEST))
{
	$sql="delete from qualification_specialization where qs_id='$_REQUEST[delete_specialization]'";
	echo $sql;
	if ($conn->query($sql) === TRUE) 
				{
					$msg= "Record Deleted Successfully";
					header("Location:../qualification-course-pecialization.php?msg=$msg ");
				} 
			else 
				{
					echo "Error: " . $sql . "<br>" . $conn->error;
				}
}
?>