<?php
$title="Home";
$bntCap="Submit";
@$state=$_POST['city_detail_state_id'];
$city_detail_id="";
$city_detail_state_id="";
$city_detail_district_id="";
$city_detail_name="";
include("include/head.php");
###################    Insert  Update  Delete Start  ###################
if(array_key_exists("add_city",$_REQUEST))
	{
	$state1=$_REQUEST['city_detail_state_id'];
	$district1=$_REQUEST['city_detail_district_id'];
	$city1=$_REQUEST['city_detail_name'];
	$all_city=$state1."-".$district1."-".$city1;
	 //$a=explode("-",$all_city);
	//print_r($a);
	//echo $a[0];
	//die();
	 if($_REQUEST['add_city']=="Submit")
		{
			$sql="insert into city_detail set
			city_detail_state_id='$_REQUEST[city_detail_state_id]',
			city_detail_district_id='$_REQUEST[city_detail_district_id]',
			city_detail_name='$_REQUEST[city_detail_name]',
			state_district_city_detail='$all_city'"; 
			if ($conn->query($sql) === TRUE) 
				{
					$msg= "Record Save successfully";
					header("Location:add-city.php?msg=$msg ");
				} 
			else 
				{
					echo "Error: " . $sql . "<br>" . $conn->error;
				}		
		}
	if($_REQUEST['add_city']=="Update")
		{
			$dt=time();
			echo $sql="Update city_detail set
			city_detail_state_id='$_REQUEST[city_detail_state_id]',
			city_detail_district_id='$_REQUEST[city_detail_district_id]',
			city_detail_name='$_REQUEST[city_detail_name]',
			state_district_city_detail='$all_city' where city_detail_id='$_REQUEST[city_detail_id]'";
			if ($conn->query($sql) === TRUE) 
				{
					echo $msg= "Record Updated successfully";
					header("Location:add-city.php?msg=$msg ");
				} 
			else 
				{
					echo "Error: " . $sql . "<br>" . $conn->error;
				}	
					
		}
	}
////////////////////////////////////////////////////////// delete_city
if(array_key_exists("edit",$_REQUEST))
	{
		$bntCap="Update";
		$sql = "SELECT * from  city_detail where city_detail_id='$_REQUEST[edit]'";
		$result = $conn->query($sql);
		$row = $result->fetch_assoc();
		$city_detail_id=$row['city_detail_id'];
		$city_detail_state_id=$row['city_detail_state_id'];
		$city_detail_district_id=$row['city_detail_district_id'];
		$city_detail_name=$row['city_detail_name'];
	} 
if(array_key_exists('delete_city',$_REQUEST))
{
	echo $sql="delete from city_detail where city_detail_id=$_REQUEST[delete_city]";
	if ($conn->query($sql) === TRUE) 
				{
					$msg= "Record Deleted Successfully";
					header("Location:add-city.php?msg=$msg ");
				} 
			else 
				{
					echo "Error: " . $sql . "<br>" . $conn->error;
				}
}
###################    Insert Delete  Update Start  ###################
?>
<!-- Paging Start -->
<link href="http://maxcdn.bootstrapcdn.com/bootstrap/3.2.0/css/bootstrap.min.css" rel="stylesheet">
<script src="http://ajax.googleapis.com/ajax/libs/jquery/1.7.1/jquery.min.js"></script>
<link rel="stylesheet" href="http://cdn.datatables.net/1.10.2/css/jquery.dataTables.min.css"></style>
<script type="text/javascript" src="http://cdn.datatables.net/1.10.2/js/jquery.dataTables.min.js"></script>
<!-- Paging end -->
<div class="page-container" >	
   <div class="left-content">
	   <div class="mother-grid-inner">
         <?php include("include/header.php"); ?>   

<!-- main Content Start --->

<!--inner block start here-->
<div class="inner-block">
    <div class="blank">
    	<?php
				if(array_key_exists("msg",$_REQUEST))
				{
				?>
					<div class="alert alert-danger" role="alert">
						<button type="button" class="close" data-dismiss="alert" aria-label="Close">  <span aria-hidden="true">&times;</span></button>
						<p class="text-center"><?php echo $_REQUEST['msg']; ?></p>
					</div>
				<?php
				} 
		?>
<!---Start -->
	<table class="table table-bordered">
			<tr>
				<td> <?php ?>
					<form name="city_request" action="" method="post" enctype="multipart/form-data">
					<div class="row form-group" >
						<div class="col-md-2 text-center">
							State Name 
						</div>
						<div class="col-md-2">
							<select class="form-control" name="city_detail_state_id" onchange="city_request.submit();" required> 
								<option >Plese Select State Name </option>
		  <?php

$state_detail_id="";
$sel="";
$sql = "SELECT * from  state_details";
$result = $conn->query($sql);
if ($result->num_rows > 0) 
	{
		 while($row = $result->fetch_assoc()) 
			{
				$state_detail_id=$row['state_detail_id'];
					if($state ==$row['state_detail_id'])
						{
							$sel="selected";
						}
					else
						{
							//$sel="";
							if($city_detail_state_id==$state_detail_id)
								{
									$sel="selected";
								}
							else
								{
									if($state ==$row['state_detail_id'])
										{
											$sel="selected";
										}
									else
										{
											$sel="";
										}
								}
						}
					
					
					
?>	
<option <?php echo $sel; ?>  value="<?php echo  $state_detail_id; ?>"><?php echo  $row['state_detail_name']; ?></option>
<?php
			 }
	}
?>
							 </select>
						</div>
						<div class="col-md-2 text-center">
							District Name 
						</div>
						<div class="col-md-2">
							<select class="form-control" name="city_detail_district_id">
								<option >Plese Select District Name </option>
 <?php
//$sql1 = "SELECT * from  district_details where district_state_id='$state' or district_id='$city_detail_district_id' or district_state_id='$city_detail_state_id'  ORDER BY district_id DESC";
if($state)
	{
		$sql1 = "SELECT * from  district_details where district_state_id='$state' ORDER BY district_id DESC";
	}
else
	{
		if($city_detail_state_id)
			{
				$sql1 = "SELECT * from  district_details where district_state_id='$city_detail_state_id'  ORDER BY district_id DESC";
			}
		else
			{
				//exit();
			}
	}
$result1 = $conn->query($sql1);
	if ($result1->num_rows > 0) 
	{
		// output data of each row
		while($row = $result1->fetch_assoc()) 
			{
				$district_id= $row['district_id'];
			if($city_detail_district_id==$district_id)
				{
					$sel1="selected";
				}
			else
				{
					$sel1="";
				}	
	?>	
				<option <?php echo $sel1; ?>  value="<?php echo  $row['district_id']; ?>"><?php echo  $row['district_name']; ?></option>
<?php
			 }
	}
?>
							 </select>
						</div>
						<div class="col-md-1 text-center">
							City Name
						</div>
						<div class="col-md-3 text-center">
							<div class="row">
								<div class="col-md-7">
								<input type="text" name="city_detail_name" value="<?php echo $city_detail_name; ?>" placeholder=" Add City Name" class="form-control" required  title="Please Enter City Name " />
								</div>
								<div class="col-md-2">
									<input class="btn btn-success" type="submit" name="add_city" value="<?php echo $bntCap; ?>">
									<input type="hidden" value="<?php echo $city_detail_id ?>" name="city_detail_id">	
								</div>
							</div>
							
						</div>
						
					</div>
					</form>
				</td>
			</tr>
		</table>
	<table id="myTable" class="table table-striped table-bordered" >  
        <thead>  
          <tr>
		  		<td>Sr. No.</td>
				<td>State Name</td>
				<td>District Name</td>
				<td>City Name</td>
				<td>Action</td>
		  </tr>
        </thead>  
        <tbody>  
 <?php
$sr="1";
$sql = "SELECT * from  state_details,district_details,city_detail where state_detail_id=district_state_id and city_detail_state_id=state_detail_id and city_detail_district_id=district_id and district_id=city_detail_district_id and city_detail_state_id=state_detail_id ORDER BY city_detail_id DESC";
$result = $conn->query($sql);
if($result-> num_rows > 0) 
	{
		// output data of each row
		while($row = $result->fetch_assoc()) 
		{
		?>
			 <tr>
					<td><?php echo $sr; ?> </td>
					<td><?php //echo  $row['state_district_city_detail']; ?><?php echo  $row['state_detail_name']; ?></td>
					<td><?php //echo  $row['city_detail_district_id']; ?><?php echo  $row['district_name']; ?></td>
					<td><?php echo  $row['city_detail_name']; ?></td>
					<td class="text-center">
					<a href="add-city.php?edit=<?php echo  $row['city_detail_id']; ?>"><label class="glyphicon glyphicon-edit"></label></a>
					<a href="#" onClick="delRecord('<?php echo  $row['city_detail_id']; ?>')"> <label class="glyphicon glyphicon-trash"></label></a>
					</td>
			  </tr>
		<?php
		$sr++;
		}
	}
$conn->close();
?>          
        </tbody>  
    </table>  
<script>
$(document).ready(function(){
    $('#myTable').dataTable();
});
</script>

<!--- end -->
    
	<br />	
		
    </div>
</div>
<!--inner block end here-->
</form>
<form name="admin" action="add-city.php" method="get">       	
<input type="hidden" name="delete_city">
</form>
<script>
function delRecord(id)
{
	if(confirm("Are you Soure you want to delete"))
	{
		document.admin.delete_city.value=id;
		document.admin.submit();
	}
}
</script>	

<!-- ----main Content End  --->
<?php include("include/footer.php"); ?>
</div>
</div>
<?php include("include/sidemenu.php"); ?>

<!--scrolling js-->
		<script src="js/jquery.nicescroll.js"></script>
		<script src="js/scripts.js"></script>
		<!--//scrolling js-->
<script src="js/bootstrap.js"> </script>
<!-- mother grid end here-->
</body>
</html>                     