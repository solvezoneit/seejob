<?php
$title="Home";
$bntCap="Submit";
include("include/head.php");
$district_name="";
$district_id="";
$district_state_id="";
if(array_key_exists("edit",$_REQUEST))
	{
		$pgtitle ="Edit Sign Up";
		$bntCap="Update";
		$sql = "SELECT * from  cities where c_id='$_REQUEST[edit]'";
		$result = $conn->query($sql);
		$row = $result->fetch_assoc();
		$district_name=$row['d_name'];
		$district_id=$row['c_id'];
		$district_state_id=$row['state_id'];
	} 
?>
<!-- paging -->
<link href="http://maxcdn.bootstrapcdn.com/bootstrap/3.2.0/css/bootstrap.min.css" rel="stylesheet">
<script src="http://ajax.googleapis.com/ajax/libs/jquery/1.7.1/jquery.min.js"></script>
<link rel="stylesheet" href="http://cdn.datatables.net/1.10.2/css/jquery.dataTables.min.css"></style>
<script type="text/javascript" src="http://cdn.datatables.net/1.10.2/js/jquery.dataTables.min.js"></script>
<script type="text/javascript" src="http://maxcdn.bootstrapcdn.com/bootstrap/3.2.0/js/bootstrap.min.js"></script>
<!-- paging -->
<div class="page-container" >	
   <div class="left-content">
	   <div class="mother-grid-inner">
         <?php include("include/header.php"); ?>   

<!-- main Content Start --->

<!--inner block start here-->
<div class="inner-block">
    <div class="blank">
    	<?php //echo $district_state_id;
				if(array_key_exists("msg",$_REQUEST))
				{
				?>
					<div class="alert alert-danger" role="alert">
						<button type="button" class="close" data-dismiss="alert" aria-label="Close">  <span aria-hidden="true">&times;</span></button>
						<p class="text-center"><?php echo $_REQUEST['msg']; ?></p>
					</div>
				<?php
				} 
		?>
		
    
	<br />	
		<table  class="table table-bordered">
			<tr>
				<td colspan="4">
				   <form action="include/query.php" method="post" enctype="multipart/form-data">
					<div class="row form-group" >
						<div class="col-md-2 text-center">
							State Name
						</div>
						<div class="col-md-3">
							<select class="form-control" name="district_state_id">
								<option >Plese Select State Name </option>
		  <?php
$sr="1";
$state_detail_id="";
$sel="";
$sql = "SELECT * from  states ORDER BY s_id DESC";
$result = $conn->query($sql);
if ($result->num_rows > 0) 
{
    // output data of each row
    while($row = $result->fetch_assoc()) 
		{
$state_detail_id=$row['s_id'];
if($state_detail_id==$district_state_id)
	{
		$sel="selected";
	}
else
	{
		$sel="";
	}		
?>	
		<option <?php echo $sel; ?>  value="<?php echo  $state_detail_id; ?>"><?php echo  $row['s_name']; ?></option>
<?php
$sr++;
   	 }
}
?>
							 </select>
						</div>
						<div class="col-md-2 text-center">
							District | City  Name
						</div>
						<div class="col-md-3">
							<input type="text" name="district_name" placeholder="District Name" required="" class="form-control" value="<?php echo $district_name; ?>">
						</div>
						<div class="col-md-2">
							<input class="btn btn-success" type="submit" name="add_district" value="<?php echo $bntCap; ?>">
							<input type="hidden" value="<?php echo $district_id ?>" name="district_id">	
						</div>
					</div>
					</form>
				</td>
			</tr>
			</table>
	<table id="myTable3" class="table table-striped responsive" >  
        <thead>  
          <tr>  
		  		<td>Sr. No.</td>
				<td>State Name</td>
				<td>District | City Name</td>
				<td>Action</td>
		  </tr>
	 </thead>
		  <?php
$sr="1";
$sql = "SELECT * from  cities,states where cities.state_id=states.s_id ORDER BY c_id DESC ";
$result = $conn->query($sql);

if ($result->num_rows > 0) {
    // output data of each row
    while($row = $result->fetch_assoc()) 
	{
?>
		 <tr>
		  		<td><?php echo $sr; //echo  $row['admin_reg_id']; ?></td>
				<td><?php echo  $row['s_name']; ?></td>
				<td><?php echo  $row['d_name']; ?></td>
				<td class="text-center">
				<a href="add-district.php?edit=<?php echo  $row['c_id']; ?>"><label class="glyphicon glyphicon-edit"></label></a> 
				<a href="#" onClick="delRecord('<?php echo  $row['c_id']; ?>')"> <label class="glyphicon glyphicon-trash"></label></a>
				</td>
		  </tr>
<?php
$sr++;
    }
}
$conn->close();

?>
		</table>
    </div>
</div>
<!--inner block end here-->

</form>
<form name="admin" action="include/query.php" method="get">       	
<input type="hidden" name="delete_district">
</form>
<script>
function delRecord(id)
{
	if(confirm("Are you Soure you want to delete"))
	{
		document.admin.delete_district.value=id;
		document.admin.submit();
	}
}
</script>	

<!-- ----main Content End  --->
<?php include("include/footer.php"); ?>
</div>
</div>
<?php include("include/sidemenu.php"); ?>

<!--scrolling js-->
		<script src="js/jquery.nicescroll.js"></script>
		<script src="js/scripts.js"></script>
		<!--//scrolling js-->
<script src="js/bootstrap.js"> </script>
<!-- mother grid end here-->
</body>
<script>
$(document).ready(function(){
    $('#myTable3').dataTable();
});
</script>

</html>                     