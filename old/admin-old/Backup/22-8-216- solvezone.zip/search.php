<?php
include("include/conection.php");
$searchTerm = $_GET['term'];
//get matched data from skills table
$query = $conn->query("SELECT * FROM  cities,states where cities.state_id=states.s_id and d_name LIKE '%".$searchTerm."%' ORDER BY d_name ASC");
//$query = $conn->query("SELECT * FROM state_details,district_details,city_detail WHERE state_detail_id=district_state_id and city_detail_state_id=state_detail_id and city_detail_district_id=district_id and district_id=city_detail_district_id and city_detail_state_id=state_detail_id  and district_name LIKE '%".$searchTerm."%' ORDER BY city_detail_name ASC");
while ($row = $query->fetch_assoc()) {
    $data[] = $row['d_name'];
}
//return json data
echo json_encode($data);
?>