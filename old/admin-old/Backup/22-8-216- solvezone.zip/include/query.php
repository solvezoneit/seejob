<?php
include("conection.php");
################################   ---     Admin  Insert Update & Delete  Start  ---     ############################
				//////// Registration (Insert & Update ) /////////
if(array_key_exists("admin_reg",$_REQUEST))
	{
	 if($_REQUEST['admin_reg']=="Submit")
		{
			$pass=md5($_REQUEST['admin_reg_password']);
			$sql="insert into admin_reg set
			admin_reg_name='$_REQUEST[admin_reg_name]',
			admin_reg_email='$_REQUEST[admin_reg_email]',
			admin_reg_password='$_REQUEST[admin_reg_password]'";
			if ($conn->query($sql) === TRUE) 
				{
					$msg= "Record Save successfully";
					header("Location:../rergistration.php?msg=$msg ");
				} 
			else 
				{
					echo "Error: " . $sql . "<br>" . $conn->error;
				}		
		}
	if($_REQUEST['admin_reg']=="Update")
		{
			$dt=time();
			$pass=md5($_REQUEST['admin_reg_password']);
			$sql="Update admin_reg set
			admin_reg_name='$_REQUEST[admin_reg_name]',
			admin_reg_email='$_REQUEST[admin_reg_email]',
			admin_reg_password='$_REQUEST[admin_reg_password]' where admin_reg_id='$_REQUEST[admin_reg_id]'";
			if ($conn->query($sql) === TRUE) 
				{
					$msg= "Record Updated successfully";
					header("Location:../rergistration.php?msg=$msg ");
				} 
			else 
				{
					echo "Error: " . $sql . "<br>" . $conn->error;
				}		
		}
	}
		//////////////////////// Delete ////////////////////////////////////////
if(array_key_exists('delete',$_REQUEST))
{
	echo $sql="delete from admin_reg where admin_reg_id=$_REQUEST[delete]";
	if ($conn->query($sql) === TRUE) 
				{
					$msg= "Record Deleted Successfully";
					header("Location:../view_rergistration.php?msg=$msg ");
				} 
			else 
				{
					echo "Error: " . $sql . "<br>" . $conn->error;
				}
}
################################   ---     Admin  Insert Update & Delete  End  ---     ############################
							//////////////////////////////////////////////////////
#####################################  Login  Page  Start ######################################
if(array_key_exists("Admin_login",$_REQUEST))
	{
				
$sql="SELECT * from  admin_reg where admin_reg_email='$_REQUEST[admin_reg_email]' and admin_reg_password='$_REQUEST[admin_reg_password]'";
$result = $conn->query($sql);
	if ($result->num_rows > 0)
		{
		// output data of each row
			$row = $result->fetch_assoc();
			if($row['admin_reg_password']==$_REQUEST['admin_reg_password'])
			{
				$_SESSION['user']=$row[admin_reg_name];
				
				header("location:../index.php");	
			}
			else
			{
				$msg="Invalid Password! try again";
				header("Location:../login.php?msg=$msg ");
			}
		}
	else
		{
			$msg="Invalid Password! try again";
			header("Location:../login.php?msg=$msg ");
		}
	}
#####################################  ----- End   --------------   ##############################################
########################## ---------  District Detail Add  Start ---- #########################################
if(array_key_exists("add_district",$_REQUEST))
	{
	 if($_REQUEST['add_district']=="Submit")
		{
			$sql="insert into cities set
			d_name='$_REQUEST[district_name]',
			state_id='$_REQUEST[district_state_id]'";
			if ($conn->query($sql) === TRUE) 
				{
					$msg= "Record Save successfully";
					header("Location:../add-district.php?msg=$msg ");
				} 
			else 
				{
					echo "Error: " . $sql . "<br>" . $conn->error;
				}		
		}
	if($_REQUEST['add_district']=="Update")
		{
			$dt=time();
			$pass=md5($_REQUEST['admin_reg_password']);
			$sql="Update cities set
			d_name='$_REQUEST[district_name]',
			state_id='$_REQUEST[district_state_id]' where c_id='$_REQUEST[district_id]'";
			if ($conn->query($sql) === TRUE) 
				{
					$msg= "Record Updated successfully";
					header("Location:../add-district.php?msg=$msg ");
				} 
			else 
				{
					echo "Error: " . $sql . "<br>" . $conn->error;
				}		
		}
	}  
if(array_key_exists('delete_district',$_REQUEST))
{
	 $sql="delete from cities where c_id=$_REQUEST[delete_district]";
	if ($conn->query($sql) === TRUE) 
				{
					$msg= "Record Deleted Successfully";
					header("Location:../add-district.php?msg=$msg ");
				} 
			else 
				{
					echo "Error: " . $sql . "<br>" . $conn->error;
				}
} 
########################## ---------  End ---- #########################################
#######    ----------   State  ( Update , Delete & Insert  ----------------     #########
if(array_key_exists("add_satae",$_REQUEST))
	{
	 if($_REQUEST['add_satae']=="Submit")
		{
			echo $sql="insert into states set
			s_name='$_REQUEST[state_detail_name]',
			country_id='$_REQUEST[country_name_id]'";
			if ($conn->query($sql) === TRUE) 
				{
					$msg= "Record Save successfully";
					header("Location:../add-state.php?msg=$msg ");
				} 
			else 
				{
					echo "Error: " . $sql . "<br>" . $conn->error;
				}		
		}
	if($_REQUEST['add_satae']=="Update")
		{
			$dt=time();
			echo $sql="Update states set
			s_name='$_REQUEST[state_detail_name]',
			country_id='$_REQUEST[n]' where s_id='$_REQUEST[state_detail_id]'";
			if ($conn->query($sql) === TRUE) 
				{
					$msg= "Record Updated successfully";
					header("Location:../add-state.php?msg=$msg ");
				} 
			else 
				{
					echo "Error: " . $sql . "<br>" . $conn->error;
				}		
		}
	}  
if(array_key_exists('delete_state',$_REQUEST))
{
	$sql="delete from states where s_id=$_REQUEST[delete_state]";
	if ($conn->query($sql) === TRUE) 
				{
					$msg= "Record Deleted Successfully";
					header("Location:../add-state.php?msg=$msg ");
				} 
			else 
				{
					echo "Error: " . $sql . "<br>" . $conn->error;
				}
} 
/*
All Delhi District & City this limk ###  http://www.census2011.co.in/census/state/districtlist/delhi.html     ####
*/
#################-------------------------         Add country  Insert  Update & Delete                 -------------------#####################################
if(array_key_exists("add_country",$_REQUEST))
	{
	 if($_REQUEST['add_country']=="Submit")
		{
			$sql="insert into countries set
			sortname='$_REQUEST[sortname]',
			name='$_REQUEST[name]',
			phonecode='$_REQUEST[phonecode]'";
			if ($conn->query($sql) === TRUE) 
				{
					$msg= "Record Save successfully";
					header("Location:../add-country.php?msg=$msg ");
				} 
			else 
				{
					echo "Error: " . $sql . "<br>" . $conn->error;
				}		
		}
	if($_REQUEST['add_country']=="Update")
		{
			$dt=time();
			$pass=md5($_REQUEST['admin_reg_password']);
			$sql="Update countries set
			sortname='$_REQUEST[sortname]',
			name='$_REQUEST[name]',
			phonecode='$_REQUEST[phonecode]' where id='$_REQUEST[id]'";
			if ($conn->query($sql) === TRUE) 
				{
					$msg= "Record Updated successfully";
					header("Location:../add-country.php?msg=$msg ");
				} 
			else 
				{
					echo "Error: " . $sql . "<br>" . $conn->error;
				}		
		}
	}  
if(array_key_exists('delete_country',$_REQUEST))
{
	 $sql="delete from countries where id=$_REQUEST[delete_country]";
	if ($conn->query($sql) === TRUE) 
				{
					$msg= "Record Deleted Successfully";
					header("Location:../add-country.php?msg=$msg ");
				} 
			else 
				{
					echo "Error: " . $sql . "<br>" . $conn->error;
				}
} 
########################## ---------  End ---- #########################################

?>