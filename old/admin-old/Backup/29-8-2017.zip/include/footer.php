<!--copy rights start here-->
<div class="copyrights">
	 <p>© 2017 Admin. All Rights Reserved | Design by  Haidar Ali </p>
</div>	
<!--COPY rights end here-->